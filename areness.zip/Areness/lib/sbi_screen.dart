import 'package:flutter/material.dart';

class SBIScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('SBI Screen'),
    );
  }
}
